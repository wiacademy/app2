
import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { SimulationProvider } from './context/SimulationContext';
import WelcomeScreen from './screens/WelcomeScreen';
import DiagnosticoCLTScreen from './screens/DiagnosticoCLTScreen';
import AutonomiaScreen from './screens/AutonomiaScreen';
import MetaScreen from './screens/MetaScreen';
import ComparacaoScreen from './screens/ComparacaoScreen';
import DiagnosticoFinalScreen from './screens/DiagnosticoFinalScreen';

const App: React.FC = () => {
  return (
    <SimulationProvider>
      <Router>
        <div className="app-container">
          <Routes>
            <Route path="/" element={<WelcomeScreen />} />
            <Route path="/diagnostico-clt" element={<DiagnosticoCLTScreen />} />
            <Route path="/resultado-autonomia" element={<AutonomiaScreen />} />
            <Route path="/simulacao-meta" element={<MetaScreen />} />
            <Route path="/comparacao-realidades" element={<ComparacaoScreen />} />
            <Route path="/diagnostico-final" element={<DiagnosticoFinalScreen />} />
          </Routes>
        </div>
      </Router>
    </SimulationProvider>
  );
};

export default App;
