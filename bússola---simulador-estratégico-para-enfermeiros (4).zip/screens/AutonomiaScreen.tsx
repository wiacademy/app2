
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useSimulation } from '../context/SimulationContext';

const AutonomiaScreen: React.FC = () => {
  const navigate = useNavigate();
  const { cltData } = useSimulation();

  const currentHourlyRate = cltData.netSalary / (cltData.hoursPerMonth || 1);

  return (
    <div className="app-container flex flex-col bg-background-dark">
      <header className="sticky top-0 z-50 bg-background-dark/80 backdrop-blur-md border-b border-white/10">
        <div className="flex items-center p-4 justify-between">
          <div onClick={() => navigate('/diagnostico-clt')} className="text-primary flex size-10 shrink-0 items-center justify-center cursor-pointer">
            <span className="material-symbols-outlined text-[20px]">arrow_back_ios_new</span>
          </div>
          <h2 className="text-white text-base font-bold leading-tight tracking-tight flex-1 text-center">Bússola de Autonomia</h2>
          <div className="flex size-10 items-center justify-end">
            <button className="flex cursor-pointer items-center justify-center rounded-lg h-10 w-10 bg-transparent text-primary active:scale-95">
              <span className="material-symbols-outlined">share</span>
            </button>
          </div>
        </div>
      </header>
      <main className="flex-1 w-full pb-12 overflow-y-auto">
        <section className="px-4 py-8">
          <h3 className="text-white tracking-tight text-3xl font-bold leading-tight text-center">
            Seu resultado está pronto, <span className="text-primary">Enfermeiro(a)</span>
          </h3>
          <p className="text-white/60 text-center mt-3 text-sm leading-relaxed">
            Analisamos seu perfil atual em comparação ao mercado privado.
          </p>
        </section>
        <div className="px-4 mb-4">
          <div className="bg-surface-dark rounded-xl p-6 shadow-xl border border-white/5">
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <p className="text-white text-base font-semibold leading-normal">Seu Valor/Hora Atual</p>
                <span className="bg-primary/20 text-primary px-2 py-1 rounded text-sm font-bold tracking-tight">R$ {currentHourlyRate.toFixed(2)}</span>
              </div>
              <div className="relative pt-2">
                <div className="h-3 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full rounded-full bg-red-500 shadow-[0_0_12px_rgba(239,68,68,0.5)]" style={{width: '25%'}}></div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-1 mt-1">
                <div className="flex flex-col items-center">
                  <p className="text-red-500 text-[10px] font-bold uppercase tracking-wider text-center">Subvalorizado</p>
                </div>
                <div className="flex flex-col items-center">
                  <p className="text-gray-500 text-[10px] font-medium uppercase tracking-wider text-center">Médio Mercado</p>
                </div>
                <div className="flex flex-col items-center">
                  <p className="text-gray-500 text-[10px] font-medium uppercase tracking-wider text-center">Premium</p>
                </div>
              </div>
            </div>
            <div className="mt-8 pt-6 border-t border-white/5">
              <p className="text-primary text-sm font-bold flex items-center gap-2 mb-2 uppercase tracking-widest">
                <span className="material-symbols-outlined text-sm">insights</span> Diagnóstico Atual
              </p>
              <p className="text-white/90 text-base leading-relaxed">
                Você recebe <span className="text-primary font-semibold italic">R$ {currentHourlyRate.toFixed(2)} por hora</span>. No mercado particular, enfermeiros com o seu perfil estão faturando entre <span className="text-green-500 font-bold">R$ 150 a R$ 300 por hora</span> em atendimentos especializados.
              </p>
            </div>
          </div>
        </div>
        <div className="px-4 mb-4">
          <div className="flex flex-col items-stretch justify-start rounded-xl shadow-lg bg-card-dark overflow-hidden border border-white/5">
            <div className="flex w-full grow flex-col items-stretch justify-center gap-3 p-5">
              <p className="text-white text-xl font-bold leading-tight tracking-tight">Custo da Omissão</p>
              <div className="flex flex-col gap-3">
                <p className="text-white/90 text-base font-normal leading-relaxed">
                  Trabalhando as mesmas {cltData.hoursPerMonth}h como autônomo, seu faturamento potencial seria de <strong className="text-primary">R$ {(cltData.hoursPerMonth * 150).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</strong>.
                </p>
                <div className="bg-black/40 rounded-lg p-3 flex items-center gap-3 border border-white/5">
                  <span className="material-symbols-outlined text-primary">analytics</span>
                  <p className="text-white/60 text-xs font-normal leading-snug italic">Isso representa uma perda de oportunidade mensal enorme.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="px-4 pb-8">
          <button 
            onClick={() => navigate('/simulacao-meta')}
            className="w-full bg-primary text-black font-bold py-4 rounded-xl shadow-lg active:scale-95 transition-transform"
          >
            SIMULAR MINHA META
          </button>
        </div>
      </main>
    </div>
  );
};

export default AutonomiaScreen;
