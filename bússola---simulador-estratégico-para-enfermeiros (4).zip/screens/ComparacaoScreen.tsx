
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useSimulation } from '../context/SimulationContext';
import { generateStrategicDiagnosis } from '../services/geminiService';

const ComparacaoScreen: React.FC = () => {
  const navigate = useNavigate();
  const { results, cltData, goalData, setAiDiagnosis, isCalculating } = useSimulation();

  const handleGetPlan = async () => {
    if (results) {
      setAiDiagnosis("Analisando seus dados com a IA da Bússola...");
      navigate('/diagnostico-final');
      const diagnosis = await generateStrategicDiagnosis(cltData, goalData, results);
      setAiDiagnosis(diagnosis);
    }
  };

  if (!results) return null;

  return (
    <div className="app-container flex flex-col bg-background-dark">
      <header className="sticky top-0 z-50 bg-background-dark/80 backdrop-blur-md border-b border-slate-800">
        <div className="flex items-center p-4 justify-between">
          <div onClick={() => navigate('/simulacao-meta')} className="flex items-center justify-center size-10 rounded-full hover:bg-slate-800 transition-colors cursor-pointer">
            <span className="material-symbols-outlined text-2xl">arrow_back_ios_new</span>
          </div>
          <h1 className="text-lg font-bold tracking-tight flex-1 text-center">Comparação de Realidades</h1>
          <div className="size-10 flex items-center justify-center">
            <span className="material-symbols-outlined text-2xl text-primary">analytics</span>
          </div>
        </div>
      </header>
      <main className="flex-1 w-full pb-40 overflow-y-auto">
        <section className="px-6 py-8">
          <h2 className="text-2xl font-bold leading-tight text-center text-white">
            A enfermagem <span className="text-primary">paga mal</span> ou o sistema te mantém preso?
          </h2>
          <p className="mt-4 text-center text-slate-300 text-sm">
            Analise os números reais entre a estagnação do regime CLT e o potencial da prática autônoma.
          </p>
        </section>
        <section className="grid grid-cols-2 gap-4 px-4">
          <div className="flex flex-col rounded-xl border border-slate-700 bg-slate-900/50 p-4 shadow-sm relative">
            <div className="mb-4">
              <div className="w-full aspect-[4/3] rounded-lg bg-cover bg-center mb-3 grayscale brightness-50" style={{backgroundImage: "url('https://picsum.photos/400/300?random=1')"}}></div>
              <span className="text-[10px] uppercase tracking-widest font-bold text-slate-400">Status Atual</span>
              <h3 className="text-lg font-bold text-slate-200">CLT Padrão</h3>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-xs text-slate-400 uppercase font-semibold">Renda Mensal</p>
                <p className="text-xl font-bold text-white">R$ {cltData.netSalary.toLocaleString('pt-BR')}</p>
              </div>
              <div>
                <p className="text-xs text-slate-400 uppercase font-semibold">Valor/Hora</p>
                <p className="text-md font-medium text-slate-300">R$ {results.currentHourlyRate.toFixed(2)}</p>
              </div>
            </div>
          </div>
          <div className="flex flex-col rounded-xl border-2 border-primary bg-slate-900 p-4 shadow-[0_0_20px_rgba(237,178,38,0.15)] relative overflow-hidden premium-card-gradient">
            <div className="mb-4">
              <div className="w-full aspect-[4/3] rounded-lg bg-cover bg-center mb-3" style={{backgroundImage: "url('https://picsum.photos/400/300?random=2')"}}></div>
              <span className="text-[10px] uppercase tracking-widest font-bold text-primary">Simulação</span>
              <h3 className="text-lg font-bold text-primary">Autônomo Pro</h3>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-xs text-primary/70 uppercase font-semibold">Renda Meta</p>
                <p className="text-xl font-bold text-primary">R$ {results.simulatedMonthlyIncome.toLocaleString('pt-BR')}</p>
              </div>
              <div>
                <p className="text-xs text-primary/70 uppercase font-semibold">Liberdade</p>
                <p className="text-md font-medium text-slate-200">{goalData.daysPerWeek} dias/semana</p>
              </div>
            </div>
          </div>
        </section>
        <section className="mt-8 px-4">
          <div className="bg-slate-900/40 rounded-xl border border-slate-800 divide-y divide-slate-800">
            <div className="p-4 flex justify-between items-center">
              <div>
                <p className="text-slate-400 text-sm font-medium">Crescimento de Renda</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-primary font-bold">R$ {results.difference.toLocaleString('pt-BR')} a mais/mês</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-emerald-500 text-xs font-bold flex items-center justify-end">
                  <span className="material-symbols-outlined text-sm">trending_up</span> {results.potentialGrowth.toFixed(0)}%
                </span>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="fixed bottom-0 inset-x-0 bg-background-dark/95 backdrop-blur-lg border-t border-slate-800 p-4 z-50 max-w-[430px] mx-auto">
        <button 
          onClick={handleGetPlan}
          className="w-full bg-primary hover:bg-[#B38F3D] text-black font-extrabold py-4 rounded-xl shadow-lg shadow-primary/20 flex items-center justify-center gap-2 transition-transform active:scale-95"
        >
          <span className="material-symbols-outlined font-bold text-black">rocket_launch</span>
          OBTER DIAGNÓSTICO IA
        </button>
      </footer>
    </div>
  );
};

export default ComparacaoScreen;
