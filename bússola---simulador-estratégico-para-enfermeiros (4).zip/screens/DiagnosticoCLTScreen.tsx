
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useSimulation } from '../context/SimulationContext';

const DiagnosticoCLTScreen: React.FC = () => {
  const navigate = useNavigate();
  const { cltData, setCltData } = useSimulation();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCltData({
      ...cltData,
      [name]: parseFloat(value) || 0
    });
  };

  const handleCalculate = () => {
    if (cltData.netSalary > 0 && cltData.hoursPerMonth > 0) {
      navigate('/resultado-autonomia');
    } else {
      alert("Por favor, preencha os campos obrigatórios para continuar.");
    }
  };

  const handleShare = async () => {
    const shareData = {
      title: 'Bússola - Simulador para Enfermeiros',
      text: 'Quanto vale seu plantão? Descubra seu real valor-hora com este simulador.',
      url: window.location.href,
    };
    if (navigator.share) await navigator.share(shareData);
  };

  return (
    <div className="app-container flex flex-col">
      <div className="flex items-center p-4 pb-2 justify-between sticky top-0 z-10 border-b border-white/5 bg-background-dark">
        <div onClick={() => navigate('/')} className="text-white flex size-12 shrink-0 items-center cursor-pointer">
          <span className="material-symbols-outlined text-white">chevron_left</span>
        </div>
        <h2 className="text-white text-lg font-bold leading-tight tracking-tight flex-1 text-center">Diagnóstico Atual</h2>
        <button 
          onClick={handleShare}
          className="flex size-12 shrink-0 items-center justify-center cursor-pointer active:scale-95 transition-transform"
        >
          <span className="material-symbols-outlined text-primary">share</span>
        </button>
      </div>
      <div className="p-4 space-y-6 flex-1 overflow-y-auto">
        <div className="bg-[#14120d] border border-primary/30 rounded-xl p-5 overflow-hidden">
          <div className="flex flex-col gap-1">
            <p className="text-primary text-xs font-semibold tracking-widest uppercase">Passo 1 de 3</p>
            <p className="text-white text-lg font-bold leading-tight">Dados da Realidade Atual</p>
            <p className="text-[#bfb59b] text-sm font-normal leading-relaxed mt-2">
              Insira seus dados financeiros atuais. Essas informações são privadas e usadas apenas para o cálculo local.
            </p>
          </div>
        </div>
        <div className="bg-[#14120d] border border-primary/40 rounded-xl p-5 space-y-5 shadow-lg">
          <div className="space-y-4">
            <label className="flex flex-col w-full">
              <p className="text-white text-sm font-medium leading-normal pb-1.5">Salário Bruto Mensal</p>
              <input 
                name="grossSalary"
                value={cltData.grossSalary || ''}
                onChange={handleInputChange}
                className="form-input flex w-full rounded-lg text-white focus:outline-0 focus:ring-1 focus:ring-primary border border-[#5d533c] bg-[#1f1b13] h-12 placeholder:text-[#bfb59b]/50 px-4 text-base font-normal" 
                placeholder="R$ 0,00" 
                type="number"
              />
            </label>
            <label className="flex flex-col w-full">
              <p className="text-white text-sm font-medium leading-normal pb-1.5">Salário Líquido Mensal</p>
              <input 
                name="netSalary"
                value={cltData.netSalary || ''}
                onChange={handleInputChange}
                className="form-input flex w-full rounded-lg text-white focus:outline-0 focus:ring-1 focus:ring-primary border border-[#5d533c] bg-[#1f1b13] h-12 placeholder:text-[#bfb59b]/50 px-4 text-base font-normal" 
                placeholder="R$ 0,00" 
                type="number"
              />
            </label>
            <div className="grid grid-cols-2 gap-4">
              <label className="flex flex-col">
                <p className="text-white text-sm font-medium leading-normal pb-1.5">Carga Horária/Mês</p>
                <input 
                  name="hoursPerMonth"
                  value={cltData.hoursPerMonth || ''}
                  onChange={handleInputChange}
                  className="form-input flex w-full rounded-lg text-white focus:outline-0 focus:ring-1 focus:ring-primary border border-[#5d533c] bg-[#1f1b13] h-12 placeholder:text-[#bfb59b]/50 px-4 text-base font-normal" 
                  placeholder="Ex: 160" 
                  type="number"
                />
              </label>
              <label className="flex flex-col">
                <p className="text-white text-sm font-medium leading-normal pb-1.5">Plantões/Semana</p>
                <input 
                  name="shiftsPerWeek"
                  value={cltData.shiftsPerWeek || ''}
                  onChange={handleInputChange}
                  className="form-input flex w-full rounded-lg text-white focus:outline-0 focus:ring-1 focus:ring-primary border border-[#5d533c] bg-[#1f1b13] h-12 placeholder:text-[#bfb59b]/50 px-4 text-base font-normal" 
                  placeholder="Ex: 2" 
                  type="number"
                />
              </label>
            </div>
          </div>
          <button 
            onClick={handleCalculate}
            className="w-full bg-primary hover:bg-[#b38f3d] active:scale-[0.98] transition-all text-[#0b0b0b] font-bold py-4 rounded-lg flex items-center justify-center gap-2 mt-2"
          >
            <span className="material-symbols-outlined">analytics</span>
            VER MEU VALOR-HORA
          </button>
        </div>
      </div>
      <div className="mt-auto h-20 bg-[#14120d] border-t border-white/5 flex items-center justify-around px-6">
        <button onClick={() => navigate('/diagnostico-clt')} className="material-symbols-outlined text-primary cursor-pointer">assessment</button>
        <button onClick={() => navigate('/resultado-autonomia')} className="material-symbols-outlined text-white/40 cursor-pointer">trending_up</button>
        <button onClick={() => navigate('/simulacao-meta')} className="material-symbols-outlined text-white/40 cursor-pointer">account_balance_wallet</button>
        <button onClick={() => navigate('/diagnostico-final')} className="material-symbols-outlined text-white/40 cursor-pointer">person</button>
      </div>
    </div>
  );
};

export default DiagnosticoCLTScreen;
