
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useSimulation } from '../context/SimulationContext';

const DiagnosticoFinalScreen: React.FC = () => {
  const navigate = useNavigate();
  const { results, aiDiagnosis, cltData } = useSimulation();

  if (!results) return null;

  const handleShare = async () => {
    const shareData = {
      title: 'Meu Diagnóstico Bússola',
      text: `Acabei de descobrir que meu potencial como enfermeiro autônomo é de R$ ${results.simulatedMonthlyIncome.toLocaleString('pt-BR')} mensais! Faça sua simulação também.`,
      url: window.location.href,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(`${shareData.text} ${shareData.url}`);
        alert('Resumo copiado para a área de transferência!');
      }
    } catch (err) {
      console.error('Erro ao compartilhar:', err);
    }
  };

  return (
    <div className="app-container flex flex-col bg-background-dark overflow-y-auto">
      <nav className="flex items-center p-4 pb-2 justify-between sticky top-0 z-50 bg-background-dark/90 backdrop-blur-sm">
        <div onClick={() => navigate('/comparacao-realidades')} className="text-primary flex size-12 shrink-0 items-center justify-start cursor-pointer">
          <span className="material-symbols-outlined text-[28px]">chevron_left</span>
        </div>
        <div className="flex flex-col items-center flex-1">
          <span className="text-primary text-[10px] uppercase tracking-[0.3em] font-bold">Mentoria</span>
          <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em]">Bússola</h2>
        </div>
        <button 
          onClick={handleShare}
          className="text-primary flex size-12 shrink-0 items-center justify-end cursor-pointer active:scale-95"
        >
          <span className="material-symbols-outlined text-[24px]">share</span>
        </button>
      </nav>

      <div className="px-4 py-3">
        <div className="w-full bg-center bg-no-repeat bg-cover flex flex-col justify-center items-center overflow-hidden bg-background-dark border border-primary/20 rounded-xl min-h-64 relative" style={{backgroundImage: 'linear-gradient(to bottom, rgba(10,9,7,0.8), rgba(10,9,7,0.95)), url("https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=800")'}}>
          <div className="absolute inset-0 bg-primary/5 mix-blend-overlay"></div>
          <span className="material-symbols-outlined text-primary text-[80px] mb-4 opacity-80 animate-pulse">psychology</span>
          <div className="px-6 text-center z-10">
            <span className="text-primary text-sm font-bold tracking-widest uppercase mb-2 block">Diagnóstico Estratégico IA</span>
            <p className="text-white text-3xl font-bold">Potencial de +{results.potentialGrowth.toFixed(0)}%</p>
            <p className="text-[#bfb59b] text-sm mt-1">Ganhos de R$ {results.simulatedMonthlyIncome.toLocaleString('pt-BR')} projetados</p>
          </div>
        </div>
      </div>

      <div className="pt-6 pb-2">
        <h1 className="text-white tracking-tight text-[28px] font-extrabold leading-tight px-6 text-center">
          Plano de <span className="text-primary">Transição Privada</span>
        </h1>
      </div>

      <div className="px-6 py-2">
        <div className="bg-white/5 border border-primary/20 rounded-2xl p-6 relative min-h-[120px] flex items-center justify-center">
          <div className="absolute -top-3 left-6 bg-primary text-black px-3 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider">
            Recomendação da IA
          </div>
          {aiDiagnosis ? (
             <p className="text-white text-base font-normal leading-relaxed text-center italic animate-in fade-in duration-700">
              "{aiDiagnosis}"
            </p>
          ) : (
            <div className="flex flex-col items-center gap-4 py-4">
               <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
               <p className="text-primary animate-pulse text-xs font-bold tracking-widest uppercase">Consultando a Bússola...</p>
            </div>
          )}
        </div>
      </div>

      <div className="p-4">
        <div className="flex flex-col items-stretch justify-start rounded-xl shadow-2xl bg-white/5 border border-white/10 backdrop-blur-sm overflow-hidden">
          <div className="flex w-full flex-col items-stretch justify-center gap-4 py-6 px-6">
            <div className="flex items-center gap-4 border-b border-white/10 pb-4">
              <div className="bg-primary/20 p-3 rounded-lg">
                <span className="material-symbols-outlined text-primary">check_circle</span>
              </div>
              <div>
                <p className="text-white text-lg font-bold leading-tight tracking-tight">Próximos Passos:</p>
              </div>
            </div>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <span className="material-symbols-outlined text-primary text-xl">looks_one</span>
                <p className="text-[#bfb59b] text-sm leading-normal">Inicie o agendamento de atendimentos particulares paralelos ao seu atual vínculo.</p>
              </li>
              <li className="flex items-start gap-3">
                <span className="material-symbols-outlined text-primary text-xl">looks_two</span>
                <p className="text-[#bfb59b] text-sm leading-normal">Foque em um nicho de alta resolutividade onde seu valor-hora seja preservado.</p>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="mt-auto px-6 pt-6 pb-12 flex flex-col gap-4">
        <a 
          className="gold-gradient gold-glow w-full py-5 rounded-xl text-[#1f1b13] text-lg font-extrabold flex items-center justify-center gap-3 active:scale-[0.98] transition-all border border-[#f5e6c4] no-underline" 
          href={`https://wa.me/5511915523329?text=Olá! Acabei de simular um potencial de R$ ${results.simulatedMonthlyIncome.toLocaleString('pt-BR')} na Bússola e quero agendar meu diagnóstico estratégico personalizado.`} 
          target="_blank"
          rel="noopener noreferrer"
        >
          <span>AGENDAR DIAGNÓSTICO</span>
          <span className="material-symbols-outlined font-bold">arrow_forward</span>
        </a>
      </div>
    </div>
  );
};

export default DiagnosticoFinalScreen;
