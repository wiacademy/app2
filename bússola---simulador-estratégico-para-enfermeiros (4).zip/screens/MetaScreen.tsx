
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useSimulation } from '../context/SimulationContext';

const MetaScreen: React.FC = () => {
  const navigate = useNavigate();
  const { goalData, setGoalData, calculateResults, results } = useSimulation();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setGoalData({
      ...goalData,
      [name]: parseFloat(value) || 0
    });
  };

  const handleSimulate = () => {
    if (goalData.desiredExtraIncome > 0 && goalData.daysPerWeek > 0) {
      calculateResults();
      navigate('/comparacao-realidades');
    } else {
      alert("Por favor, preencha seus objetivos para simular.");
    }
  };

  return (
    <div className="app-container flex flex-col bg-background-dark">
      <div className="flex items-center bg-background-dark p-4 pb-2 justify-between sticky top-0 z-10 border-b border-[#5d533c]/20">
        <div onClick={() => navigate('/resultado-autonomia')} className="text-primary flex size-12 shrink-0 items-center justify-center cursor-pointer">
          <span className="material-symbols-outlined text-3xl">arrow_back_ios</span>
        </div>
        <h2 className="text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center pr-12">Simulação de Meta</h2>
      </div>
      <div className="px-4 pt-6 overflow-y-auto flex-1">
        <h2 className="text-white tracking-light text-[28px] font-extrabold leading-tight pb-2 pt-2">Defina seus objetivos</h2>
        <p className="text-[#bfb59b] text-sm pb-6">Compare seu ganho atual com o potencial do atendimento particular.</p>
        
        <div className="space-y-4">
          <div className="flex flex-wrap items-end gap-4">
            <label className="flex flex-col min-w-40 flex-1">
              <p className="text-white text-base font-semibold leading-normal pb-2">Renda mensal extra desejada</p>
              <div className="flex w-full flex-1 items-stretch rounded-lg shadow-sm">
                <input 
                  name="desiredExtraIncome"
                  value={goalData.desiredExtraIncome || ''}
                  onChange={handleInputChange}
                  className="form-input flex w-full min-w-0 flex-1 rounded-lg text-white border border-[#5d533c] bg-[#1e1b15] focus:border-primary h-14 p-[15px] rounded-r-none border-r-0 pr-2 text-lg font-bold" 
                  placeholder="R$ 5.000,00" 
                  type="number"
                />
                <div className="text-[#bfb59b] flex border border-[#5d533c] bg-[#1e1b15] items-center justify-center pr-[15px] rounded-r-lg border-l-0">
                  <span className="material-symbols-outlined">payments</span>
                </div>
              </div>
            </label>
          </div>
          <div className="flex flex-wrap items-end gap-4">
            <label className="flex flex-col min-w-40 flex-1">
              <p className="text-white text-base font-semibold leading-normal pb-2">Dias de atendimento por semana</p>
              <div className="flex w-full flex-1 items-stretch rounded-lg shadow-sm">
                <input 
                  name="daysPerWeek"
                  value={goalData.daysPerWeek || ''}
                  onChange={handleInputChange}
                  className="form-input flex w-full min-w-0 flex-1 rounded-lg text-white border border-[#5d533c] bg-[#1e1b15] focus:border-primary h-14 p-[15px] rounded-r-none border-r-0 pr-2" 
                  placeholder="Ex: 3" 
                  type="number"
                />
                <div className="text-[#bfb59b] flex border border-[#5d533c] bg-[#1e1b15] items-center justify-center pr-[15px] rounded-r-lg border-l-0">
                  <span className="material-symbols-outlined">calendar_month</span>
                </div>
              </div>
            </label>
          </div>
          <div className="flex flex-wrap gap-4">
            <label className="flex flex-col min-w-[120px] flex-1">
              <p className="text-white text-base font-semibold leading-normal pb-2">Horas por dia</p>
              <input 
                name="hoursPerDay"
                value={goalData.hoursPerDay || ''}
                onChange={handleInputChange}
                className="form-input flex w-full rounded-lg text-white border border-[#5d533c] bg-[#1e1b15] focus:border-primary h-14 p-[15px]" 
                placeholder="Ex: 6" 
                type="number"
              />
            </label>
            <label className="flex flex-col min-w-[120px] flex-1">
              <p className="text-white text-base font-semibold leading-normal pb-2">Atendimentos por dia</p>
              <input 
                name="appointmentsPerDay"
                value={goalData.appointmentsPerDay || ''}
                onChange={handleInputChange}
                className="form-input flex w-full rounded-lg text-white border border-[#5d533c] bg-[#1e1b15] focus:border-primary h-14 p-[15px]" 
                placeholder="Ex: 4" 
                type="number"
              />
            </label>
          </div>
        </div>

        <div className="py-8">
          <button 
            onClick={handleSimulate}
            className="w-full bg-primary text-zinc-900 font-bold py-4 rounded-xl shadow-lg shadow-primary/20 transition-all active:scale-95 flex items-center justify-center gap-2"
          >
            <span className="material-symbols-outlined">calculate</span>
            SIMULAR NOVO CENÁRIO
          </button>
        </div>
      </div>
    </div>
  );
};

export default MetaScreen;
