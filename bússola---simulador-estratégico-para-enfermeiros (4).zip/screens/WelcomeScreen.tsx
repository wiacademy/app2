
import React from 'react';
import { useNavigate } from 'react-router-dom';

const WelcomeScreen: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="relative flex min-h-screen flex-col items-center justify-between px-8 py-16 subtle-mesh overflow-hidden">
      <div className="flex flex-col items-center w-full mt-10">
        <div className="flex flex-col items-center gap-3">
          <div className="flex size-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-[#9e7a2e] text-background-dark gold-shadow">
            <span className="material-symbols-outlined !text-4xl font-bold">explore</span>
          </div>
          <span className="text-sm font-bold tracking-[0.4em] uppercase gold-gradient-text">Bússola</span>
        </div>
      </div>
      <div className="flex flex-col items-center text-center w-full max-w-sm">
        <h1 className="text-[44px] font-extrabold leading-[1.05] tracking-tight text-white mb-6">
          Quanto Vale Seu <span className="gold-gradient-text">Plantão?</span>
        </h1>
        <p className="text-lg font-medium leading-relaxed text-white/90 mb-12 max-w-[280px]">
          Simulador Estratégico Oficial Bússola para enfermeiros de alto impacto.
        </p>
        <div className="w-full flex justify-center">
          <button 
            onClick={() => navigate('/diagnostico-clt')}
            className="group relative flex w-full max-w-[300px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-16 bg-primary text-background-dark text-lg font-bold transition-all active:scale-95 gold-shadow"
          >
            <span className="relative z-10 flex items-center gap-3">
              Iniciar Simulação
              <span className="material-symbols-outlined !text-2xl">arrow_forward</span>
            </span>
            <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
          </button>
        </div>
      </div>
      <div className="flex flex-col items-center mb-4">
        <p className="text-[11px] font-medium tracking-[0.2em] text-white/30 uppercase">
          Official Bússola Experience
        </p>
      </div>
      <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-primary/5 blur-[120px]"></div>
    </div>
  );
};

export default WelcomeScreen;
