
import { GoogleGenAI } from "@google/genai";
import { CLTData, GoalData, SimulationResult } from "../types";

export const generateStrategicDiagnosis = async (
  clt: CLTData,
  goal: GoalData,
  result: SimulationResult
): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const prompt = `
      Atue como um mentor estratégico de carreira para enfermeiros na metodologia "Bússola".
      
      Dados reais da simulação:
      - Horas CLT atuais: ${clt.hoursPerMonth}h mensais.
      - Faturamento projetado como Autônomo: R$ ${result.simulatedMonthlyIncome.toLocaleString('pt-BR')}
      - Crescimento potencial: ${result.potentialGrowth.toFixed(0)}%
      - Dias de trabalho desejados: ${goal.daysPerWeek} dias/semana.

      Sua tarefa é gerar um parágrafo persuasivo e profissional seguindo exatamente esta estrutura, substituindo os valores:

      "Seu diagnóstico revela uma armadilha de tempo: você entrega ${clt.hoursPerMonth} horas mensais para um retorno que subestima sua competência. O maior gargalo é a baixa valorização da sua hora no modelo CLT. Para atingir o potencial de R$ ${result.simulatedMonthlyIncome.toLocaleString('pt-BR')} com apenas ${goal.daysPerWeek} dias de trabalho, você precisa migrar para um nicho premium. Com a estratégia Bússola, você deixa de ser um custo operacional para se tornar uma autoridade de elite. O mercado particular busca exclusividade, e sua autonomia financeira começa no momento em que você decide escalar seu valor-hora."

      Retorne apenas o texto, sem formatação markdown ou aspas externas.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        temperature: 0.7,
      }
    });

    return response.text?.trim() || "Não foi possível gerar o diagnóstico no momento.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return `Seu diagnóstico revela um potencial de R$ ${result.simulatedMonthlyIncome.toLocaleString('pt-BR')} trabalhando apenas ${goal.daysPerWeek} dias por semana. O modelo CLT atual consome ${clt.hoursPerMonth}h do seu mês. É hora de transicionar para o mercado premium e valorizar sua hora técnica.`;
  }
};
