
export interface CLTData {
  grossSalary: number;
  netSalary: number;
  hoursPerMonth: number;
  shiftsPerWeek: number;
  timeAwayFromHome: number;
}

export interface GoalData {
  desiredExtraIncome: number;
  daysPerWeek: number;
  hoursPerDay: number;
  appointmentsPerDay: number;
}

export interface SimulationResult {
  currentHourlyRate: number;
  currentShiftValue: number;
  simulatedMonthlyIncome: number;
  simulatedHourlyRate: number;
  potentialGrowth: number;
  difference: number;
}

export interface SimulationContextType {
  cltData: CLTData;
  setCltData: (data: CLTData) => void;
  goalData: GoalData;
  setGoalData: (data: GoalData) => void;
  results: SimulationResult | null;
  calculateResults: () => void;
  isCalculating: boolean;
  aiDiagnosis: string;
  setAiDiagnosis: (val: string) => void;
}
