
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const BottomNav: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { icon: 'assessment', path: '/diagnostico-clt' },
    { icon: 'trending_up', path: '/resultado-autonomia' },
    { icon: 'account_balance_wallet', path: '/simulacao-meta' },
    { icon: 'person', path: '/diagnostico-final' },
  ];

  return (
    <div className="mt-auto h-20 bg-[#14120d] border-t border-white/5 flex items-center justify-around px-6 sticky bottom-0 z-50">
      {navItems.map((item) => (
        <button 
          key={item.path}
          onClick={() => navigate(item.path)}
          className={`material-symbols-outlined cursor-pointer transition-all active:scale-90 ${
            location.pathname === item.path ? 'text-primary' : 'text-white/40 hover:text-white/60'
          }`}
        >
          {item.icon}
        </button>
      ))}
    </div>
  );
};

export default BottomNav;
