
import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'gold' | 'ghost';
  icon?: string;
  fullWidth?: boolean;
}

const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  icon, 
  fullWidth = true, 
  className = '', 
  ...props 
}) => {
  const baseStyles = "flex items-center justify-center gap-2 rounded-xl py-4 px-6 font-bold transition-all active:scale-[0.98] disabled:opacity-50";
  
  const variants = {
    primary: "bg-primary text-background-dark gold-shadow hover:brightness-110",
    gold: "gold-gradient gold-glow text-[#1f1b13] border border-[#f5e6c4] font-extrabold uppercase tracking-tight",
    ghost: "bg-transparent text-primary border border-primary/20 hover:bg-primary/5"
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${fullWidth ? 'w-full' : ''} ${className}`} 
      {...props}
    >
      {children}
      {icon && <span className="material-symbols-outlined font-bold">{icon}</span>}
    </button>
  );
};

export default Button;
