
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useShare } from '../../hooks/useShare';

interface HeaderProps {
  title: string;
  subtitle?: string;
  backTo?: string;
  showShare?: boolean;
  shareData?: { title: string; text: string };
  isTransparent?: boolean;
}

const Header: React.FC<HeaderProps> = ({ 
  title, 
  subtitle, 
  backTo, 
  showShare, 
  shareData,
  isTransparent = false 
}) => {
  const navigate = useNavigate();
  const share = useShare();

  const handleBack = () => backTo ? navigate(backTo) : navigate(-1);

  return (
    <nav className={`flex items-center p-4 sticky top-0 z-50 transition-colors ${isTransparent ? 'bg-transparent' : 'bg-background-dark/90 backdrop-blur-sm border-b border-white/5'}`}>
      <div onClick={handleBack} className="text-primary flex size-12 shrink-0 items-center justify-start cursor-pointer hover:opacity-70">
        <span className="material-symbols-outlined text-[28px]">chevron_left</span>
      </div>
      
      <div className="flex flex-col items-center flex-1">
        {subtitle && <span className="text-primary text-[10px] uppercase tracking-[0.3em] font-bold">{subtitle}</span>}
        <h2 className="text-white text-lg font-bold leading-tight tracking-tight">{title}</h2>
      </div>

      <div className="size-12 flex items-center justify-end">
        {showShare && (
          <button 
            onClick={() => share(shareData || { title: 'Bússola', text: 'Confira meu diagnóstico!' })}
            className="text-primary flex items-center justify-center size-10 active:scale-95 transition-transform"
          >
            <span className="material-symbols-outlined text-[24px]">share</span>
          </button>
        )}
      </div>
    </nav>
  );
};

export default Header;
