
import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  icon?: string;
}

const Input: React.FC<InputProps> = ({ label, icon, className = '', ...props }) => {
  return (
    <label className="flex flex-col w-full group">
      <p className="text-white text-sm font-medium leading-normal pb-2 transition-colors group-focus-within:text-primary">{label}</p>
      <div className="relative flex items-center">
        <input 
          className={`form-input flex w-full rounded-lg text-white border border-[#5d533c] bg-[#1e1b15] focus:border-primary focus:ring-1 focus:ring-primary/20 h-14 px-4 text-base font-medium transition-all outline-none ${icon ? 'pr-12' : ''} ${className}`} 
          {...props}
        />
        {icon && (
          <div className="absolute right-4 text-[#bfb59b] group-focus-within:text-primary transition-colors">
            <span className="material-symbols-outlined">{icon}</span>
          </div>
        )}
      </div>
    </label>
  );
};

export default Input;
