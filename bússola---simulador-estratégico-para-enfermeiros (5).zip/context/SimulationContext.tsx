
import React, { createContext, useContext, useState, useCallback } from 'react';
import { CLTData, GoalData, SimulationResult, SimulationContextType } from '../types';
import { calculateSimulation } from '../utils/calculations';

const SimulationContext = createContext<SimulationContextType | undefined>(undefined);

export const SimulationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cltData, setCltData] = useState<CLTData>({
    grossSalary: 0,
    netSalary: 0,
    hoursPerMonth: 0,
    shiftsPerWeek: 0,
    timeAwayFromHome: 0,
  });

  const [goalData, setGoalData] = useState<GoalData>({
    desiredExtraIncome: 0,
    daysPerWeek: 0,
    hoursPerDay: 0,
    appointmentsPerDay: 0,
  });

  const [results, setResults] = useState<SimulationResult | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [aiDiagnosis, setAiDiagnosis] = useState('');

  const calculateResults = useCallback(() => {
    setIsCalculating(true);
    const simulatedResults = calculateSimulation(cltData, goalData);
    setResults(simulatedResults);
    setIsCalculating(false);
  }, [cltData, goalData]);

  return (
    <SimulationContext.Provider value={{
      cltData, setCltData,
      goalData, setGoalData,
      results, calculateResults,
      isCalculating,
      aiDiagnosis, setAiDiagnosis
    }}>
      {children}
    </SimulationContext.Provider>
  );
};

export const useSimulation = () => {
  const context = useContext(SimulationContext);
  if (!context) throw new Error('useSimulation must be used within a SimulationProvider');
  return context;
};
