
import { useCallback } from 'react';

interface ShareParams {
  title: string;
  text: string;
  url?: string;
}

export const useShare = () => {
  const share = useCallback(async (params: ShareParams) => {
    const shareData = {
      title: params.title,
      text: params.text,
      url: params.url || window.location.href,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(`${shareData.text} ${shareData.url}`);
        alert('Copiado para a área de transferência!');
      }
    } catch (err) {
      if ((err as Error).name !== 'AbortError') {
        console.error('Erro ao compartilhar:', err);
      }
    }
  }, []);

  return share;
};
