
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useSimulation } from '../context/SimulationContext';
import Header from '../components/ui/Header';
import Button from '../components/ui/Button';
import BottomNav from '../components/ui/BottomNav';

const AutonomiaScreen: React.FC = () => {
  const navigate = useNavigate();
  const { cltData } = useSimulation();

  const currentHourlyRate = cltData.netSalary / (cltData.hoursPerMonth || 1);

  return (
    <div className="app-container flex flex-col bg-background-dark min-h-screen">
      <Header 
        title="Bússola de Autonomia" 
        backTo="/diagnostico-clt" 
        showShare 
        shareData={{ title: 'Bússola', text: `Meu valor hora atual é R$ ${currentHourlyRate.toFixed(2)}. Veja o seu!` }}
      />
      
      <main className="flex-1 w-full pb-12 overflow-y-auto">
        <section className="px-6 py-8">
          <h3 className="text-white tracking-tight text-3xl font-extrabold leading-tight text-center">
            Seu resultado está pronto, <span className="text-primary">Enfermeiro(a)</span>
          </h3>
          <p className="text-white/60 text-center mt-3 text-sm leading-relaxed">
            Analisamos seu perfil atual em comparação ao mercado privado de elite.
          </p>
        </section>

        <div className="px-6 mb-6">
          <div className="bg-[#14120d] rounded-2xl p-8 shadow-2xl border border-primary/20 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <span className="material-symbols-outlined text-[100px] text-primary">payments</span>
            </div>
            
            <div className="flex flex-col gap-6 relative z-10">
              <div className="flex items-center justify-between">
                <p className="text-[#bfb59b] text-sm font-bold uppercase tracking-widest">Valor/Hora Atual</p>
                <span className="bg-primary/20 text-primary px-3 py-1 rounded-full text-lg font-black">R$ {currentHourlyRate.toFixed(2)}</span>
              </div>
              
              <div className="space-y-3">
                <div className="h-2.5 rounded-full bg-white/5 overflow-hidden">
                  <div className="h-full rounded-full bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.4)]" style={{width: '25%'}}></div>
                </div>
                <div className="flex justify-between text-[10px] font-bold uppercase tracking-tighter text-white/40">
                  <span className="text-red-500/80">Subvalorizado</span>
                  <span>Média</span>
                  <span>Premium</span>
                </div>
              </div>

              <div className="mt-4 pt-6 border-t border-white/5">
                <p className="text-primary text-xs font-black flex items-center gap-2 mb-3 uppercase tracking-[0.2em]">
                  <span className="material-symbols-outlined text-sm">info</span> Diagnóstico Imediato
                </p>
                <p className="text-white/90 text-base leading-relaxed font-medium">
                  Atualmente você recebe <span className="text-primary font-bold">R$ {currentHourlyRate.toFixed(2)}</span> por hora. No mercado particular premium, sua hora técnica vale entre <span className="text-green-500 font-bold">R$ 150 a R$ 350</span>.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="px-6 mb-10">
          <div className="bg-white/[0.02] rounded-2xl p-6 border border-white/5">
            <h4 className="text-white font-bold text-lg mb-2">Custo da Omissão</h4>
            <p className="text-[#bfb59b] text-sm leading-relaxed">
              Mantendo sua carga horária de {cltData.hoursPerMonth}h no mercado autônomo, seu faturamento ultrapassaria <strong className="text-primary">R$ {(cltData.hoursPerMonth * 150).toLocaleString('pt-BR')}</strong>. Você está deixando dinheiro na mesa todos os meses.
            </p>
          </div>
        </div>

        <div className="px-6">
          <Button onClick={() => navigate('/simulacao-meta')} icon="trending_up" variant="gold">
            SIMULAR MINHA META
          </Button>
        </div>
      </main>

      <BottomNav />
    </div>
  );
};

export default AutonomiaScreen;
