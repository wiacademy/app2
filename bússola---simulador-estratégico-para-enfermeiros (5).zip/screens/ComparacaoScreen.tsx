
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useSimulation } from '../context/SimulationContext';
import { generateStrategicDiagnosis } from '../services/geminiService';
import Header from '../components/ui/Header';
import Button from '../components/ui/Button';

const ComparacaoScreen: React.FC = () => {
  const navigate = useNavigate();
  const { results, cltData, goalData, setAiDiagnosis } = useSimulation();

  const handleGetPlan = async () => {
    if (results) {
      setAiDiagnosis(""); // Reseta o diagnóstico anterior
      navigate('/diagnostico-final');
      const diagnosis = await generateStrategicDiagnosis(cltData, goalData, results);
      setAiDiagnosis(diagnosis);
    }
  };

  if (!results) return null;

  return (
    <div className="app-container flex flex-col bg-background-dark min-h-screen">
      <Header title="Realidade vs Potencial" backTo="/simulacao-meta" />
      
      <main className="flex-1 w-full pb-32 overflow-y-auto">
        <section className="px-6 py-8">
          <h2 className="text-2xl font-black leading-tight text-center text-white">
            A enfermagem <span className="text-primary">paga mal</span> ou você está no lugar errado?
          </h2>
          <p className="mt-4 text-center text-[#bfb59b] text-sm">
            Compare os números da sua carga horária atual contra o modelo de autonomia Bússola.
          </p>
        </section>

        <section className="grid grid-cols-2 gap-4 px-4">
          <div className="flex flex-col rounded-2xl border border-white/5 bg-white/[0.02] p-5 relative overflow-hidden">
            <div className="mb-4">
              <div className="w-full aspect-square rounded-xl bg-cover bg-center mb-4 grayscale opacity-40 border border-white/10" style={{backgroundImage: "url('https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&q=80&w=400')"}}></div>
              <span className="text-[10px] uppercase tracking-[0.2em] font-black text-white/30">Cenário CLT</span>
              <h3 className="text-lg font-bold text-white/70">Estagnação</h3>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-[10px] text-white/40 uppercase font-bold">Renda Líquida</p>
                <p className="text-lg font-bold text-white">R$ {cltData.netSalary.toLocaleString('pt-BR')}</p>
              </div>
              <div>
                <p className="text-[10px] text-white/40 uppercase font-bold">Valor/Hora</p>
                <p className="text-sm font-medium text-white/60">R$ {results.currentHourlyRate.toFixed(2)}</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col rounded-2xl border-2 border-primary/40 bg-[#14120d] p-5 shadow-[0_0_30px_rgba(237,178,38,0.1)] relative overflow-hidden">
            <div className="absolute top-0 right-0 w-12 h-12 bg-primary/20 blur-2xl"></div>
            <div className="mb-4">
              <div className="w-full aspect-square rounded-xl bg-cover bg-center mb-4 border border-primary/20" style={{backgroundImage: "url('https://images.unsplash.com/photo-1551288560-199736d31ca4?auto=format&fit=crop&q=80&w=400')"}}></div>
              <span className="text-[10px] uppercase tracking-[0.2em] font-black text-primary">Cenário Bússola</span>
              <h3 className="text-lg font-bold text-primary">Elite Privada</h3>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-[10px] text-primary/50 uppercase font-bold">Potencial</p>
                <p className="text-lg font-bold text-primary">R$ {results.simulatedMonthlyIncome.toLocaleString('pt-BR')}</p>
              </div>
              <div>
                <p className="text-[10px] text-primary/50 uppercase font-bold">Liberdade</p>
                <p className="text-sm font-medium text-white/80">{goalData.daysPerWeek} dias/semana</p>
              </div>
            </div>
          </div>
        </section>

        <section className="mt-8 px-4">
          <div className="bg-primary/10 rounded-2xl border border-primary/20 p-6 flex justify-between items-center shadow-inner">
            <div>
              <p className="text-[#bfb59b] text-xs font-bold uppercase tracking-widest">Upgrade Mensal</p>
              <p className="text-primary text-xl font-black mt-1">R$ {results.difference.toLocaleString('pt-BR')} a mais</p>
            </div>
            <div className="bg-primary text-background-dark px-3 py-1.5 rounded-lg font-black text-sm flex items-center gap-1">
              <span className="material-symbols-outlined text-sm">trending_up</span>
              {results.potentialGrowth.toFixed(0)}%
            </div>
          </div>
        </section>
      </main>

      <div className="fixed bottom-0 inset-x-0 bg-background-dark/95 backdrop-blur-xl border-t border-white/5 p-6 z-50 max-w-[430px] mx-auto">
        <Button onClick={handleGetPlan} variant="gold" icon="auto_awesome">
          OBTER DIAGNÓSTICO IA
        </Button>
      </div>
    </div>
  );
};

export default ComparacaoScreen;
