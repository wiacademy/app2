
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useSimulation } from '../context/SimulationContext';
import Header from '../components/ui/Header';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import BottomNav from '../components/ui/BottomNav';

const DiagnosticoCLTScreen: React.FC = () => {
  const navigate = useNavigate();
  const { cltData, setCltData } = useSimulation();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCltData({
      ...cltData,
      [name]: parseFloat(value) || 0
    });
  };

  const handleCalculate = () => {
    if (cltData.netSalary > 0 && cltData.hoursPerMonth > 0) {
      navigate('/resultado-autonomia');
    } else {
      alert("Por favor, preencha os campos obrigatórios para continuar.");
    }
  };

  return (
    <div className="app-container flex flex-col min-h-screen">
      <Header 
        title="Diagnóstico Atual" 
        backTo="/" 
        showShare 
        shareData={{ title: 'Bússola', text: 'Veja meu valor hora como enfermeiro!' }}
      />
      
      <div className="p-4 space-y-6 flex-1 overflow-y-auto">
        <div className="bg-[#14120d] border border-primary/30 rounded-xl p-5 shadow-sm">
          <div className="flex flex-col gap-1">
            <p className="text-primary text-xs font-semibold tracking-widest uppercase">Passo 1 de 3</p>
            <p className="text-white text-lg font-bold">Dados da Realidade Atual</p>
            <p className="text-[#bfb59b] text-sm mt-2 leading-relaxed">
              Analise sua saúde financeira atual. Dados processados localmente e com total privacidade.
            </p>
          </div>
        </div>

        <div className="bg-[#14120d] border border-primary/40 rounded-xl p-6 space-y-5 shadow-xl">
          <Input 
            label="Salário Bruto Mensal" 
            name="grossSalary" 
            type="number" 
            value={cltData.grossSalary || ''} 
            onChange={handleInputChange} 
            placeholder="R$ 0,00"
          />
          <Input 
            label="Salário Líquido Mensal" 
            name="netSalary" 
            type="number" 
            value={cltData.netSalary || ''} 
            onChange={handleInputChange} 
            placeholder="R$ 0,00"
          />
          <div className="grid grid-cols-2 gap-4">
            <Input 
              label="Horas Mensais" 
              name="hoursPerMonth" 
              type="number" 
              value={cltData.hoursPerMonth || ''} 
              onChange={handleInputChange} 
              placeholder="Ex: 160"
            />
            <Input 
              label="Plantões/Sem" 
              name="shiftsPerWeek" 
              type="number" 
              value={cltData.shiftsPerWeek || ''} 
              onChange={handleInputChange} 
              placeholder="Ex: 2"
            />
          </div>
          
          <Button onClick={handleCalculate} icon="analytics" className="mt-2">
            VER MEU VALOR-HORA
          </Button>
        </div>
      </div>
      
      <BottomNav />
    </div>
  );
};

export default DiagnosticoCLTScreen;
