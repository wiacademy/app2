
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSimulation } from '../context/SimulationContext';
import Header from '../components/ui/Header';
import Button from '../components/ui/Button';

const DiagnosticoFinalScreen: React.FC = () => {
  const navigate = useNavigate();
  const { results, aiDiagnosis, cltData, goalData } = useSimulation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  if (!results) return null;

  const whatsappMessage = `Olá! Acabei de simular um potencial de R$ ${results.simulatedMonthlyIncome.toLocaleString('pt-BR')} na Bússola e quero agendar meu diagnóstico estratégico personalizado.`;
  const whatsappUrl = `https://wa.me/5511915523329?text=${encodeURIComponent(whatsappMessage)}`;

  return (
    <div className="app-container flex flex-col bg-background-dark min-h-screen overflow-y-auto">
      <Header 
        title="Bússola" 
        subtitle="Mentoria" 
        backTo="/comparacao-realidades" 
        showShare 
        shareData={{ 
          title: 'Meu Diagnóstico Bússola', 
          text: `Meu potencial é de R$ ${results.simulatedMonthlyIncome.toLocaleString('pt-BR')} mensais!` 
        }} 
      />

      <div className="px-4 py-4">
        <div 
          className="w-full bg-center bg-no-repeat bg-cover flex flex-col justify-center items-center overflow-hidden bg-background-dark border border-primary/20 rounded-2xl min-h-[260px] relative shadow-2xl" 
          style={{backgroundImage: 'linear-gradient(to bottom, rgba(10,9,7,0.85), rgba(10,9,7,0.98)), url("https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=800")'}}
        >
          <div className="absolute inset-0 bg-primary/5 mix-blend-overlay"></div>
          <span className="material-symbols-outlined text-primary text-[80px] mb-4 opacity-70 animate-pulse">psychology</span>
          <div className="px-6 text-center z-10">
            <span className="text-primary text-xs font-bold tracking-[0.2em] uppercase mb-2 block">Análise Estratégica IA</span>
            <p className="text-white text-3xl font-extrabold tracking-tight">Potencial de +{results.potentialGrowth.toFixed(0)}%</p>
            <p className="text-[#bfb59b] text-sm mt-1 font-medium">Meta de R$ {results.simulatedMonthlyIncome.toLocaleString('pt-BR')} / mês</p>
          </div>
        </div>
      </div>

      <div className="pt-6 px-6 text-center">
        <h1 className="text-white text-[28px] font-black leading-tight tracking-tight">
          Plano de <span className="text-primary">Transição Pro</span>
        </h1>
      </div>

      <div className="px-6 py-6">
        <div className="bg-white/[0.03] border border-primary/10 rounded-2xl p-6 relative min-h-[140px] flex items-center justify-center shadow-inner">
          <div className="absolute -top-3 left-6 bg-primary text-background-dark px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest shadow-lg">
            Diagnóstico Bússola
          </div>
          {aiDiagnosis ? (
             <p className="text-white text-base font-medium leading-relaxed text-center italic animate-in fade-in slide-in-from-bottom-2 duration-1000">
              "{aiDiagnosis}"
            </p>
          ) : (
            <div className="flex flex-col items-center gap-4 py-4">
               <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
               <p className="text-primary animate-pulse text-[10px] font-bold tracking-widest uppercase">Consultando a Inteligência...</p>
            </div>
          )}
        </div>
      </div>

      <div className="px-6 mb-8">
        <div className="rounded-2xl bg-white/[0.02] border border-white/5 p-6 space-y-5">
          <div className="flex items-center gap-4 border-b border-white/5 pb-4">
            <div className="bg-primary/10 p-2.5 rounded-lg">
              <span className="material-symbols-outlined text-primary">verified</span>
            </div>
            <p className="text-white text-lg font-bold">Mapa de Execução</p>
          </div>
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <span className="material-symbols-outlined text-primary text-2xl">rocket</span>
              <p className="text-[#bfb59b] text-sm leading-relaxed">Posicionamento como especialista no mercado privado para elevar seu valor-hora imediatamente.</p>
            </div>
            <div className="flex items-start gap-4">
              <span className="material-symbols-outlined text-primary text-2xl">schedule</span>
              <p className="text-[#bfb59b] text-sm leading-relaxed">Cronograma de migração segura para sair do CLT sem perder estabilidade financeira.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-auto px-6 pb-12">
        <Button 
          variant="gold" 
          icon="arrow_forward" 
          onClick={() => window.open(whatsappUrl, '_blank')}
          className="py-5"
        >
          AGENDAR DIAGNÓSTICO
        </Button>
      </div>
    </div>
  );
};

export default DiagnosticoFinalScreen;
