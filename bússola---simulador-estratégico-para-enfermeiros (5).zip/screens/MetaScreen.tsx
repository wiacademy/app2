
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useSimulation } from '../context/SimulationContext';
import Header from '../components/ui/Header';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';

const MetaScreen: React.FC = () => {
  const navigate = useNavigate();
  const { goalData, setGoalData, calculateResults } = useSimulation();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setGoalData({
      ...goalData,
      [name]: parseFloat(value) || 0
    });
  };

  const handleSimulate = () => {
    if (goalData.desiredExtraIncome > 0 && goalData.daysPerWeek > 0) {
      calculateResults();
      navigate('/comparacao-realidades');
    } else {
      alert("Por favor, defina seus objetivos para prosseguir.");
    }
  };

  return (
    <div className="app-container flex flex-col bg-background-dark min-h-screen">
      <Header title="Simulação de Meta" backTo="/resultado-autonomia" />
      
      <div className="px-6 pt-8 overflow-y-auto flex-1 pb-10">
        <h2 className="text-white text-3xl font-extrabold leading-tight tracking-tight">
          Defina seu <span className="text-primary">Novo Estilo</span> de Vida
        </h2>
        <p className="text-[#bfb59b] text-sm mt-3 mb-8">O mercado privado permite que você escolha quanto quer ganhar e quanto quer trabalhar.</p>
        
        <div className="space-y-6">
          <Input 
            label="Renda Mensal Desejada" 
            name="desiredExtraIncome" 
            type="number" 
            value={goalData.desiredExtraIncome || ''} 
            onChange={handleInputChange} 
            icon="payments" 
            placeholder="Ex: R$ 8.000,00"
          />
          
          <Input 
            label="Dias de Atendimento / Semana" 
            name="daysPerWeek" 
            type="number" 
            value={goalData.daysPerWeek || ''} 
            onChange={handleInputChange} 
            icon="calendar_month" 
            placeholder="Ex: 3"
          />
          
          <div className="grid grid-cols-2 gap-4">
            <Input 
              label="Horas / Dia" 
              name="hoursPerDay" 
              type="number" 
              value={goalData.hoursPerDay || ''} 
              onChange={handleInputChange} 
              placeholder="Ex: 6"
            />
            <Input 
              label="Pacientes / Dia" 
              name="appointmentsPerDay" 
              type="number" 
              value={goalData.appointmentsPerDay || ''} 
              onChange={handleInputChange} 
              placeholder="Ex: 4"
            />
          </div>
        </div>

        <div className="pt-10">
          <Button onClick={handleSimulate} icon="calculate">
            SIMULAR CENÁRIO PREMIUM
          </Button>
        </div>
      </div>
    </div>
  );
};

export default MetaScreen;
