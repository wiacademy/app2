
import { GoogleGenAI } from "@google/genai";
import { CLTData, GoalData, SimulationResult } from "../types";

export const generateStrategicDiagnosis = async (
  clt: CLTData,
  goal: GoalData,
  result: SimulationResult
): Promise<string> => {
  try {
    // Inicializa a IA usando a chave que você vai configurar no painel do Vercel
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const prompt = `
      Atue como um mentor estratégico de carreira para enfermeiros na metodologia "Bússola".
      
      Dados da simulação:
      - Horas CLT atuais: ${clt.hoursPerMonth}h mensais.
      - Faturamento projetado como Autônomo: R$ ${result.simulatedMonthlyIncome.toLocaleString('pt-BR')}
      - Crescimento potencial: ${result.potentialGrowth.toFixed(0)}%
      - Dias de trabalho desejados: ${goal.daysPerWeek} dias/semana.

      Sua tarefa é gerar um parágrafo persuasivo seguindo esta estrutura exata (mantenha o tom profissional e motivador):

      "Seu diagnóstico revela uma armadilha de tempo: você entrega ${clt.hoursPerMonth} horas mensais para um retorno que subestima sua competência. O maior gargalo é a baixa valorização da sua hora no modelo CLT. Para atingir o potencial de R$ ${result.simulatedMonthlyIncome.toLocaleString('pt-BR')} com apenas ${goal.daysPerWeek} dias de trabalho, você precisa migrar para um nicho premium. Com a estratégia Bússola, você deixa de ser um custo operacional para se tornar uma autoridade de elite."

      Retorne apenas o texto final, sem comentários adicionais.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        temperature: 0.7,
      }
    });

    return response.text?.trim() || "Seu diagnóstico revela um alto potencial de crescimento no mercado privado de enfermagem.";
  } catch (error) {
    console.error("Erro na API Gemini:", error);
    return `Seu diagnóstico aponta um potencial de faturamento de R$ ${result.simulatedMonthlyIncome.toLocaleString('pt-BR')} com foco em atendimentos particulares de elite.`;
  }
};
