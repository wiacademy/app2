
import { CLTData, GoalData, SimulationResult } from '../types';

export const calculateSimulation = (cltData: CLTData, goalData: GoalData): SimulationResult => {
  const currentHourlyRate = cltData.netSalary / (cltData.hoursPerMonth || 1);
  const currentShiftValue = currentHourlyRate * 12; // Padrão de plantão de 12h
  
  // Preço médio de mercado para atendimento particular premium
  const marketAppointmentPrice = 250; 
  const simulatedMonthlyIncome = goalData.daysPerWeek * 4 * goalData.appointmentsPerDay * marketAppointmentPrice;
  const simulatedHourlyRate = simulatedMonthlyIncome / (goalData.daysPerWeek * 4 * (goalData.hoursPerDay || 1) || 1);
  
  const potentialGrowth = ((simulatedMonthlyIncome - cltData.netSalary) / (cltData.netSalary || 1)) * 100;
  const difference = simulatedMonthlyIncome - cltData.netSalary;

  return {
    currentHourlyRate,
    currentShiftValue,
    simulatedMonthlyIncome,
    simulatedHourlyRate,
    potentialGrowth,
    difference
  };
};
